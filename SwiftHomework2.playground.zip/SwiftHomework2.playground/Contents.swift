import UIKit
//Tuple is a group of elements that use ().The elements inside tuple can be different types.Tuple can be access by many ways,which are indes,decomposing tuple and naming elements in tuple.
//Array is also a group of elements but it use [].An array can be empty or fill with elements.The element inside an array can be retrieve.We can also use range when we want to do something with an array

//Example for tuple
var Tuple1 : (String,Int) = ("This is a tuple",1)
print(Tuple1)

//Example for array
var Array1 : [Any] = ["This is an array",2]
print(Array1)
